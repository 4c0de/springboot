-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-09-2017 a las 11:17:22
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `spring`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `nombre` varchar(256) NOT NULL,
  `descripcion` mediumtext NOT NULL,
  `url` text NOT NULL,
  `categoria` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`id`, `nombre`, `descripcion`, `url`, `categoria`) VALUES
(2, ' Tarta de manzana', 'Con una masa quebrada cubres la base de un molde. Lo llenas con la crema pastelera y lo cubres con láminas de manzana en crudo y un poco de azúcar. Se hornea y luego se decora con unas cucharadas de mermelada de melocotón o albaricoque.', 'http://www.panabad.com/_images/product/165/407_modal.png', 'Dulces'),
(3, 'Bandeja de pasteles', 'Alaska de fresa, barquita de frambuesa, bocadito de nata, bomba de naranja, canutillo de crema, capuchina, disco de chocolate, eclair de caramelo.', 'http://www.pasteleriaenparla.es/wp-content/uploads/2014/09/BandejaPasteles.png', 'Dulces'),
(4, 'TARTA TRES CHOCOLATES', 'Bizcocho de chocolate con mousse de chocolate blanco, chocolate de leche y chocolate negro con un baño de chocolate negro brillante.', 'https://pastelesdlulu.com/wp-content/uploads/2013/10/pasteldechocolate20.png', 'Dulces'),
(5, 'Donuts', 'Donuts relleno de chocolate ', 'http://donuts.es/wp-content/uploads/2016/09/Donuts-relleno-imagen-web-.png', 'Bollería'),
(6, 'Pan cateto', 'El Pan Cateto, así denominado en Málaga, según tengo entendido, es un pan blanco, de miga compacta, practicamente nada alveolada, con  una corteza dura, con un muy bajo nivel de hidratación y preparado con un tipo de harina denominada “harina recia”.', 'http://blogs.21rs.es/corazones/files/2015/06/redondo-sb-400-gr.png', 'Panes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pesoitem`
--

CREATE TABLE `pesoitem` (
  `id` int(11) NOT NULL,
  `peso` int(11) NOT NULL,
  `iditem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pesoitem`
--

INSERT INTO `pesoitem` (`id`, `peso`, `iditem`) VALUES
(1, 200, 2),
(2, 500, 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pesoitem`
--
ALTER TABLE `pesoitem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `pesoitem`
--
ALTER TABLE `pesoitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
